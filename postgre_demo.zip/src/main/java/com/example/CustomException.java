package com.example;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode(callSuper = true)
@Data
public class CustomException extends Exception {
    // Getters for key and value, if needed
    private final String key;
    private final String value;
    private final String errorMessage;


    public CustomException(String key, String value, String message) {
        this.key = key;
        this.value = value;
        this.errorMessage = "{\"key\":\"" + key + "\",\"message\":\"" + message + "\"}";
    }

}
