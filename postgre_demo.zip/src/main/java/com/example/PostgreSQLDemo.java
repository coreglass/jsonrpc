package com.example;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.example.DO.DataDAO;
import com.example.DO.DataVO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;


public class PostgreSQLDemo {

    public static void main(String[] args) {


        EntityManagerFactory emf = Persistence.createEntityManagerFactory("YourPersistenceUnitName");
        EntityManager entityManager = emf.createEntityManager();
        DataEntityService dataEntityService = new DataEntityService(entityManager);
        String jsonArrayString = "[{\"teacher\":{\"sex\":\"Male\",\"name\":\"Mr. Smith\",\"age\":35},\"student\":{\"sex\":\"Female\",\"name\":\"Alice\",\"age\":20},\"school\":{\"class1\":{\"class2\":{\"class3\":{\"name\":\"Math Class\"}}}},\"vinId\":12312332112},{\"teacher\":{\"sex\":\"Male\",\"name\":\"Mr. Smith\",\"age\":35},\"student\":{\"sex\":\"Female\",\"name\":\"Alice\",\"age\":20},\"school\":{\"class1\":{\"class2\":{\"class3\":{\"name\":\"Math Class\"}}}},\"vinId\":12314223113211}]";
        List<Object> exceptions = new ArrayList<>(); // 创建保存异常的列表

        try {
            JSONArray jsonArray = JSONArray.parseArray(jsonArrayString);

            // 输出JSONArray对象中的每个元素
            for (int i = 0; i < jsonArray.size(); i++) {
                try {
                    String jsonStr = String.valueOf(jsonArray.getJSONObject(i));

                    DataDAO dataBO = MapToBO.mapToBO(jsonStr);

                    System.out.println(dataBO.getStudent().getName());

                    System.out.println("mapToDataBO:" + dataBO);
                    jisuan.jisuan(i);
                    EntityTransaction transaction = entityManager.getTransaction();
                    transaction.begin();
                    // 将 DataDAO 对象映射为 DataDO 对象
                    DataVO dataVO = mapToDataDO.mapToDataVO(dataBO);
//                String jsonStr1 = JSON.toJSONString(dataVO);
//                System.out.println(jsonStr1);
//                // 使用 DataEntityService 将 DataDO 对象保存到数据库中
                    dataEntityService.save(dataVO);
                    DataVO re = dataEntityService.getDataEntityById(11111L);
                    System.out.println("Element " + (i + 1) + ": " + re);
                    transaction.commit();
                } catch (CustomException e) {
                    exceptions.add(e.toString());
                    continue;
                }
            }

        } catch (Exception e) {
            exceptions.add(e.toString());
        } finally {
            entityManager.close();
            emf.close();
        }
        System.out.println("异常信息有："+exceptions);
    }
}
