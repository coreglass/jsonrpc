package com.example;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.example.DO.DataDAO;

public class MapToBO {
    public static DataDAO mapToBO(String jsonStr) throws CustomException {
        DataDAO dataDAO = new DataDAO();
        try {
            dataDAO = JSONObject.parseObject(jsonStr, DataDAO.class);
        } catch (JSONException e) {
            throw new CustomException("vinId","xxxxxxxxx","JSON 解析失败");
        }
        return dataDAO;
    }
}
