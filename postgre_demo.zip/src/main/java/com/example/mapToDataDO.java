package com.example;

import com.example.DO.DataDAO;
import com.example.DO.DataVO;


public class mapToDataDO {

    public static DataVO mapToDataVO(DataDAO dataDAO) {
        DataVO data = new DataVO();
        System.out.println(dataDAO.getVinId());
        data.setVinId(dataDAO.getVinId());
        System.out.println(dataDAO.getStudent().getName());
        data.setStudent_name(dataDAO.getStudent().getName());
        data.setStudent_age(13);
        data.setStudent_sex("女");
        data.setTeacher_name("nihao");
        data.setTeacher_age(25);
        data.setTeacher_sex("nan");
        data.setSchool_class1_class2_class3_name("123");

        // 设置其他属性，根据需要映射 dataStructure 的其他字段到 dataDO 对象
        return data;
    }
}