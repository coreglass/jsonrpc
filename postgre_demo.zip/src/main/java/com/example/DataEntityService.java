package com.example;

import com.example.DO.DataVO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

public class DataEntityService {


    @PersistenceContext
    private EntityManager entityManager;
    public DataEntityService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }


    public DataVO getDataEntityById(Long vinId) {
        return entityManager.find(DataVO.class, vinId);
    }

    @Transactional
    public void save(DataVO json) {
        entityManager.persist(json);
        entityManager.flush();
    }
}
