package com.example.DO;

import lombok.Data;

@Data
public class DataDAO {

        private Teacher teacher;
        private Student student;
        private School school;
        private Long vinId;

        // Getters and setters

        @Data
        public static class Teacher {
            private String sex;
            private String name;
            private int age;
        }
        @Data
        public static class Student {
            private String sex;
            private String name;
            private int age;
        }
    @Data
        public static class School {
            private Class1 class1;

            @Data
            public static class Class1 {
                private Class2 class2;

                @Data
                public static class Class2 {
                    private Class3 class3;

                    @Data
                    public static class Class3 {
                        private String name;

                    }
                }
            }
        }
}
