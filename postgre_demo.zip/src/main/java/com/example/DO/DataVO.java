package com.example.DO;
import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "Data")
public class DataVO {
    @Id
    private Long vinId;
    private String teacher_sex;
    private String teacher_name;
    private int teacher_age;
    private String student_sex;
    private String student_name;
    private int student_age;
    private String school_class1_class2_class3_name;
    }
