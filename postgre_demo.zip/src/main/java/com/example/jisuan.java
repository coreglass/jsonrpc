package com.example;


public class jisuan {
    public static void jisuan(int n) throws CustomException {
        try {
            int a = 1/0;
        } catch (Exception e) {
            throw new CustomException("vinId",n+"","1/0????");
        }
    }
}
