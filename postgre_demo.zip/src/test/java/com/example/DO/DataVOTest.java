package com.example.DO;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DataVOTest {

    @Test
    public void testDataVOGetterSetter() {
        DataVO dataVO = new DataVO();
        dataVO.setVinId(123456L);
        dataVO.setTeacher_sex("Male");
        dataVO.setTeacher_name("John");
        dataVO.setTeacher_age(30);
        dataVO.setStudent_sex("Female");
        dataVO.setStudent_name("Alice");
        dataVO.setStudent_age(25);
        dataVO.setSchool_class1_class2_class3_name("Math Class");

        assertEquals(123456L, dataVO.getVinId());
        assertEquals("Male", dataVO.getTeacher_sex());
        assertEquals("John", dataVO.getTeacher_name());
        assertEquals(30, dataVO.getTeacher_age());
        assertEquals("Female", dataVO.getStudent_sex());
        assertEquals("Alice", dataVO.getStudent_name());
        assertEquals(25, dataVO.getStudent_age());
        assertEquals("Math Class", dataVO.getSchool_class1_class2_class3_name());
    }
}
