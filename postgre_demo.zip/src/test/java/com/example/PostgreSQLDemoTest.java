package com.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import static org.mockito.Mockito.*;

public class PostgreSQLDemoTest {

    @Mock
    private EntityManager entityManager;

    @Mock
    private EntityTransaction transaction;

    @InjectMocks
    private DataEntityService dataEntityService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        when(entityManager.getTransaction()).thenReturn(transaction);
    }

    @Test
    public void testSaveDataEntity() {
        PostgreSQLDemo demo = new PostgreSQLDemo();
        demo.main(null);

        // 验证事务的开始和提交是否被调用
        verify(transaction, times(2)).begin(); // 两次循环，每次都应该开始一个事务
        verify(transaction, times(2)).commit(); // 两次循环，每次都应该提交一个事务

        // 在这里还可以进行更多的验证，例如对数据库的保存行为进行模拟和验证
    }

    // 可以编写更多的测试方法来覆盖其他场景
}
