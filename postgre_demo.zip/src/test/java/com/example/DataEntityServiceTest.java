package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class DataEntityServiceTest {

    @Test
    void getDataEntityById() {
    }

    @Test
    void save() {
    }
}